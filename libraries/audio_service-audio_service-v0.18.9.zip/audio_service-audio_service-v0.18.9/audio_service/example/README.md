# audio_service_example

[This example](https://github.com/ryanheise/audio_service/blob/master/example/lib/main.dart) demonstrates how to play an audio file or text-to-speech in the background.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
